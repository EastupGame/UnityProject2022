using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    float health = 50.0f;
    void Start()
    {

    }
    void TakeDamage(int value)
    {
        health -= value;
    }
    public float GetHealth()
    {
        return health;
    }
    void Die()
    {
        Destroy(this.gameObject);
    }
    public void OnCollisionEnter2D(Collision2D coll)
    {
        TakeDamage(10);
        Debug.Log("health : "+health);
        coll.gameObject.SetActive(false);
        if (health <= 0) { Die(); }
    }

    void Update()
    {

    }
}
